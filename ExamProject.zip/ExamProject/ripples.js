class Ripple{
    constructor(x, y) {
        this.x = x + 20;
        this.y = y + 20;
        this.radius = Math.random() * 20 + 1;
        this.opacity = 1;
        this.directionX = Math.random() * 1 - 0.5;
        this.directionY = Math.random() * 1 - 0.5;
    }
}